// lista de Catálogo de filmes
var catalogo =[
  {
    titulo: "Filme 1",
    genero: "Ação/crime",
    ano: "2011"
  },
  {
    titulo: "Filme 2",
    genero: "Faroeste/drama",
    ano: "2012"
  },
    {
    titulo: "Filme 3",
    genero: "Suspense/Drama",
    ano: "1999"
    },
    {
      titulo: "Filme 4",
      genero: "Ação e drama",
      ano: "2012"
    },

];

function buscarFilmes(pesquisa) {
// Converter a pesquisa para letras minúsculas para ignorar a capitalização
  pesquisa = pesquisa.toLowerCase();
  
// Filtrar o catálogo com base na pesquisa
  var resultados = catalogo.filter(function(filme) {
// Verificar se o título ou gênero contêm na pesquisa
    return filme.titulo.toLowerCase().includes(pesquisa) || filme.genero.toLowerCase().includes(pesquisa);
  });
  
// Retornar os resultados da pesquisa
  return resultados;
}
